
## IMPORTS ##
from flask import Flask, render_template, json, redirect
from flask_mysqldb import MySQL
from flask import request
import os
## IMPORTS ##


## DATABASE CONECTION AND CONFIG ##
app = Flask(__name__)
app.config["MYSQL_HOST"] = "classmysql.engr.oregonstate.edu"
app.config["MYSQL_USER"] = "cs340_davisg4"
app.config["MYSQL_PASSWORD"] = "8778"
app.config["MYSQL_DB"] = "cs340_davisg4"
app.config["MYSQL_CURSORCLASS"] = "DictCursor"
mysql = MySQL(app)
## DATABASE CONECTION AND CONFIG ##



#       Table of contents because this is one hefty file            #
#                                                                   #
#       Page                                line #                  #
#                                                                   #
#                                                                   # 
#       Root / Home  .....................  50                      #
#       Authors  .........................                          #
#       Books  ...........................                          #
#       Employees  .......................                          #
#       Genres  ..........................                          #
#       Members  .........................                          #
#       Orders  ..........................                          #
#                                                                   #
#                                                                   #
#                                                                   #






# INIT # INIT # INIT # INIT # INIT # INIT # INIT # INIT # INIT # INIT # INIT # INIT # INIT # INIT # INIT # INIT # INIT # INIT # INIT # INIT # INIT # INIT # 
###########################################################################################################################################################
# HOMEPAGE # HOMEPAGE # HOMEPAGE # HOMEPAGE # HOMEPAGE # HOMEPAGE # HOMEPAGE # HOMEPAGE # HOMEPAGE # HOMEPAGE # HOMEPAGE # HOMEPAGE # HOMEPAGE # HOMEPAGE # 


@app.route('/')
def root():
    return redirect("/home")
@app.route('/home')
def home():
    return render_template('home.j2')


# HOMEPAGE # HOMEPAGE # HOMEPAGE # HOMEPAGE # HOMEPAGE # HOMEPAGE # HOMEPAGE # HOMEPAGE # HOMEPAGE # HOMEPAGE # HOMEPAGE # HOMEPAGE # HOMEPAGE # HOMEPAGE # HOMEPAGE # HOMEPAGE # HOMEPAGE # HOMEPAGE # HOMEPAGE # HOMEPAGE # 
#############################################################################################################################################################################################################################
# AUTHORS # AUTHORS # AUTHORS # AUTHORS # AUTHORS # AUTHORS # AUTHORS # AUTHORS # AUTHORS # AUTHORS # AUTHORS # AUTHORS # AUTHORS # AUTHORS # AUTHORS # AUTHORS # AUTHORS # AUTHORS # AUTHORS # AUTHORS # AUTHORS # AUTHORS # 


# WORKING (CREATE, READ)
@app.route("/authors", methods=["POST", "GET"])
def authors():
    if request.method == "POST":
        if request.form.get("Add_Author"):
            Name = request.form["Name"]
            BirthDate = request.form["BirthDate"]
            Nationality = request.form["Nationality"]
            query = "INSERT INTO Authors (Name, BirthDate, Nationality) VALUES (%s, %s, %s)"
            cur = mysql.connection.cursor()
            cur.execute(query, (Name, BirthDate, Nationality))
            mysql.connection.commit()
            return redirect("/authors")
    if request.method == "GET":
        query = "SELECT AuthorID, Name, BirthDate, Nationality FROM Authors"
        cur = mysql.connection.cursor()
        cur.execute(query)
        data = cur.fetchall()
        return render_template("authors.j2", data=data)
# WORKING (UPDATE)
@app.route("/edit_author/<int:AuthorID>", methods=["POST", "GET"])
def edit_author(AuthorID):
    if request.method == "GET":
        query = "SELECT * FROM Authors WHERE AuthorID = %s"
        cur = mysql.connection.cursor()
        cur.execute(query, (AuthorID,))
        data = cur.fetchall()
        return render_template("edit_author.j2", data=data)
    if request.method == "POST":
        if request.form.get("Edit_Author"):
            AuthorID = request.form["AuthorID"]
            Name = request.form["Name"]
            BirthDate = request.form["BirthDate"]
            Nationality = request.form["Nationality"]
            query = "UPDATE Authors SET Name = %s, BirthDate = %s, Nationality = %s WHERE AuthorID = %s"
            cur = mysql.connection.cursor()
            cur.execute(query, (Name, BirthDate, Nationality, AuthorID))
            mysql.connection.commit()
            return redirect("/authors")
# WORKING (DELETE)
@app.route("/delete_author/<int:AuthorID>")
def delete_author(AuthorID):
    query = "DELETE FROM Authors WHERE AuthorID = %s"
    cur = mysql.connection.cursor()
    cur.execute(query, (AuthorID,))
    mysql.connection.commit()
    return redirect("/authors")


# AUTHORS # AUTHORS # AUTHORS # AUTHORS # AUTHORS # AUTHORS # AUTHORS # AUTHORS # AUTHORS # AUTHORS # AUTHORS # AUTHORS # AUTHORS # AUTHORS # AUTHORS # AUTHORS #
#################################################################################################################################################################
# BOOKS # BOOKS # BOOKS # BOOKS # BOOKS # BOOKS # BOOKS # BOOKS # BOOKS # BOOKS # BOOKS # BOOKS # BOOKS # BOOKS # BOOKS # BOOKS # BOOKS # BOOKS # BOOKS # BOOKS # 


# WORKING (CREATE, READ)
@app.route('/books', methods=["GET", "POST"])
def books():
    if request.method == "POST":
        title = request.form["title"]
        isbn = request.form["isbn"]
        year_published = request.form["year_published"]
        publisher = request.form["publisher"]
        page_count = request.form["page_count"]
        language = request.form["language"]
        on_hold = bool(request.form.get("on_hold"))
        checked_out = bool(request.form.get("checked_out"))
        query = "INSERT INTO Books (Title, ISBN, YearPublished, Publisher, PageCount, Language, OnHold, CheckedOut) VALUES (%s, %s, %s, %s, %s, %s, %s, %s);"
        cur = mysql.connection.cursor()
        cur.execute(query, (title, isbn, year_published, publisher, page_count, language, on_hold, checked_out))
        mysql.connection.commit()
        return redirect('/books')
    cur = mysql.connection.cursor()
    cur.execute("SELECT * FROM Books;")
    books_data = cur.fetchall()
    return render_template("books.j2", books=books_data)
# WORKING (UPDATE)
@app.route('/edit_book/<int:bookID>', methods=["GET", "POST"])
def edit_book(bookID):
    if request.method == "POST":
        title = request.form["title"]
        isbn = request.form["isbn"]
        year_published = request.form["year_published"]
        publisher = request.form["publisher"]
        page_count = request.form["page_count"]
        language = request.form["language"]
        on_hold = bool(request.form.get("on_hold"))
        checked_out = bool(request.form.get("checked_out")) 
        query = """UPDATE Books 
                   SET Title = %s, ISBN = %s, YearPublished = %s, Publisher = %s, PageCount = %s, Language = %s, OnHold = %s, CheckedOut = %s
                   WHERE BookID = %s;"""
        data = (title, isbn, year_published, publisher, page_count, language, on_hold, checked_out, bookID)
        cur = mysql.connection.cursor()
        cur.execute(query, data)
        mysql.connection.commit()
        return redirect('/books')   
    cur = mysql.connection.cursor()
    cur.execute("SELECT * FROM Books WHERE BookID = %s;", (bookID,))
    book = cur.fetchone()
    return render_template("edit_book.j2", book=book)
# WORKING (DELETE)
@app.route('/delete_book/<int:bookID>')
def delete_book(bookID):
    cur = mysql.connection.cursor()
    cur.execute("DELETE FROM Books WHERE BookID = %s;", (bookID,))
    mysql.connection.commit()
    return redirect('/books')


# BOOKS # BOOKS # BOOKS # BOOKS # BOOKS # BOOKS # BOOKS # BOOKS # BOOKS # BOOKS # BOOKS # BOOKS # BOOKS # BOOKS # BOOKS # BOOKS # BOOKS # BOOKS #  
#################################################################################################################################################
# EMPLOYEES # EMPLOYEES # EMPLOYEES # EMPLOYEES # EMPLOYEES # EMPLOYEES # EMPLOYEES # EMPLOYEES # EMPLOYEES # EMPLOYEES # EMPLOYEES # EMPLOYEES #


# WORKING (CREATE, READ)
@app.route("/employees", methods=["POST", "GET"])
def employees():
    if request.method == "POST":
        if request.form.get("Add_Employee"):
            Name = request.form["Name"]
            Position = request.form["Position"]
            Email = request.form["Email"]
            Phone = request.form["Phone"]
            query = "INSERT INTO Employees (Name, Position, Email, Phone) VALUES (%s, %s, %s, %s)"  ## QUERY ##
            cur = mysql.connection.cursor()
            cur.execute(query, (Name, Position, Email, Phone))
            mysql.connection.commit()
            return redirect("/employees")
    if request.method == "GET":
        query = "SELECT EmployeeID, Name, Position, Email, Phone FROM Employees"  ## QUERY ##
        cur = mysql.connection.cursor()
        cur.execute(query)
        data = cur.fetchall()
        return render_template("employees.j2", data=data)
# WORKING (UPDATE)
@app.route("/edit_employee/<int:EmployeeID>", methods=["POST", "GET"])
def edit_employee(EmployeeID):
    if request.method == "GET":
        query = "SELECT * FROM Employees WHERE EmployeeID = %s;" % (EmployeeID)
        cur = mysql.connection.cursor()
        cur.execute(query)
        data = cur.fetchall()
        return render_template("edit_employee.j2", data=data)
    if request.method == "POST":
        if request.form.get("Edit_Employee"):
            EmployeeID = request.form["EmployeeID"]
            Name = request.form["Name"]
            Position = request.form["Position"]
            Email = request.form["Email"]
            Phone = request.form["Phone"]
            query = "UPDATE Employees SET Name = %s, Position = %s, Email = %s, Phone = %s WHERE EmployeeID = %s;"
            cur = mysql.connection.cursor()
            cur.execute(query, (Name, Position, Email, Phone, EmployeeID))
            mysql.connection.commit()
            return redirect("/employees")
# Working (DELETE)
@app.route("/delete_employee/<int:EmployeeID>")
def delete_employee(EmployeeID):
    query = "DELETE FROM Employees WHERE EmployeeID = %s;"  ## QUERY ##
    cur = mysql.connection.cursor()
    cur.execute(query, (EmployeeID,))
    mysql.connection.commit()
    return redirect("/employees")


# EMPLOYEES # EMPLOYEES # EMPLOYEES # EMPLOYEES # EMPLOYEES # EMPLOYEES # EMPLOYEES # EMPLOYEES # EMPLOYEES # EMPLOYEES # EMPLOYEES # EMPLOYEES #
#################################################################################################################################################
# GENRE # GENRE # GENRE # GENRE # GENRE # GENRE # GENRE # GENRE # GENRE # GENRE # GENRE # GENRE # GENRE # GENRE # GENRE # GENRE # GENRE # GENRE # 


#WORKING (CREATE, READ)
@app.route("/genres", methods=["POST", "GET"])
def genres():
    if request.method == "POST":
        if request.form.get("Add_Genre"):
            GenreID = request.form["GenreID"]
            GenreDescription = request.form["GenreDescription"]
            query = "INSERT INTO Genres (GenreID, GenreDescription) VALUES (%s, %s)"  ## QUERY ##
            cur = mysql.connection.cursor()
            cur.execute(query, (GenreID, GenreDescription))
            mysql.connection.commit()
            return redirect("/genres")
    if request.method == "GET":
        query = "SELECT GenreID, GenreDescription FROM Genres" ## QUERY ##
        cur = mysql.connection.cursor()
        cur.execute(query)
        data = cur.fetchall()
        return render_template("genres.j2", data=data)
# WORKING (UPDATE)
@app.route("/edit_genre/<string:GenreID>", methods=["POST", "GET"])
def edit_genre(GenreID):
    if request.method == "GET":
        query = "SELECT * FROM Genres WHERE GenreID = %s" ## QUERY ##
        cur = mysql.connection.cursor()
        cur.execute(query, (GenreID,))
        data = cur.fetchall()
        return render_template("edit_genre.j2", data=data)
    if request.method == "POST":
        if request.form.get("Edit_Genre"):
            GenreID = request.form["GenreID"]
            GenreDescription = request.form["GenreDescription"]
            query = "UPDATE Genres SET GenreDescription = %s WHERE GenreID = %s" ## QUERY ##
            cur = mysql.connection.cursor()
            cur.execute(query, (GenreDescription, GenreID))
            mysql.connection.commit()
            return redirect("/genres")
#WORKING (DELETE)
@app.route("/delete_genre/<GenreID>")
def delete_genre(GenreID):
    query = "DELETE FROM Genres WHERE GenreID = '%s';" % (GenreID) ## QUERY ##
    cur = mysql.connection.cursor()
    cur.execute(query)
    mysql.connection.commit()
    return redirect("/genres")


# GENRE # GENRE # GENRE # GENRE # GENRE # GENRE # GENRE # GENRE # GENRE # GENRE # GENRE # GENRE # GENRE # GENRE # GENRE # GENRE # GENRE # GENRE # 
#################################################################################################################################################
# MEMBER # MEMBER # MEMBER # MEMBER # MEMBER # MEMBER # MEMBER # MEMBER # MEMBER # MEMBER # MEMBER # MEMBER # MEMBER # MEMBER # MEMBER # MEMBER #


# WORKING (CREATE, READ)
@app.route("/members", methods=["POST", "GET"])
def members():
    if request.method == "POST":
        if request.form.get("Add_Member"):
            Email = request.form["Email"]	
            Name = request.form["Name"]	
            Phone = request.form["Phone"]	
            Address = request.form["Address"]	
            Standing = "Good"	
            CurrentFines = 0.00
            query = "INSERT INTO Members (Email, Name, Phone, Address, Standing, CurrentFines) VALUES (%s, %s, %s, %s, %s, %s)"  ## QUERY ##
            cur = mysql.connection.cursor()
            cur.execute(query, (Email, Name, Phone, Address, Standing, CurrentFines))
            mysql.connection.commit()
            return redirect("/members")
    if request.method == "GET":
        query = "SELECT MemberID, Email, Name, Phone, Address, Standing, CurrentFines FROM Members" ## QUERY ##
        cur = mysql.connection.cursor()
        cur.execute(query)
        data = cur.fetchall()
        return render_template("members.j2", data=data)
# WORKING (UPDATE)
@app.route("/edit_member/<int:MemberID>", methods=["POST", "GET"])
def edit_member(MemberID):
    if request.method == "GET":
        query = "SELECT * FROM Members WHERE MemberID = %s;" % (MemberID)
        cur = mysql.connection.cursor()
        cur.execute(query)
        data = cur.fetchall()
        return render_template("edit_member.j2", data=data)
    if request.method == "POST":
        if request.form.get("Edit_Member"):
            MemberID = request.form["MemberID"]	
            Email = request.form["Email"]	
            Name = request.form["Name"]	
            Phone = request.form["Phone"]	
            Address = request.form["Address"]	
            Standing = request.form["Standing"]	
            CurrentFines = request.form["CurrentFines"]	
            if Address == "" or Address == "None" or Address == None:
                query = "UPDATE Members SET Members.Email = %s, Members.Name = %s, Members.Phone = %s, Members.Address = NULL, Members.Standing = %s, Members.CurrentFines = %s WHERE Members.MemberID = %s;"
                cur = mysql.connection.cursor()
                cur.execute(query, (Email, Name, Phone, Standing, CurrentFines, MemberID))
                mysql.connection.commit()
            else:
                query = "UPDATE Members SET Members.Email = %s, Members.Name = %s, Members.Phone = %s, Members.Address = %s, Members.Standing = %s, Members.CurrentFines = %s WHERE Members.MemberID = %s;"
                cur = mysql.connection.cursor()
                cur.execute(query, (Email, Name, Phone, Address, Standing, CurrentFines, MemberID))
                mysql.connection.commit()
            return redirect("/members")
# Working (DELETE)
@app.route("/delete_member/<int:MemberID>")
def delete_member(MemberID):
    # return redirect("/books")
    query = "DELETE FROM Members WHERE MemberID = %s;" ## QUERY ##
    cur = mysql.connection.cursor()
    cur.execute(query, (MemberID,))
    mysql.connection.commit()
    return redirect("/members")

# MEMBER # MEMBER # MEMBER # MEMBER # MEMBER # MEMBER # MEMBER # MEMBER # MEMBER # MEMBER # MEMBER # MEMBER # MEMBER # MEMBER # MEMBER # MEMBER #
#################################################################################################################################################
# ORDERS # ORDERS # ORDERS # ORDERS # ORDERS # ORDERS # ORDERS # ORDERS # ORDERS # ORDERS # ORDERS # ORDERS # ORDERS # ORDERS # ORDERS # ORDERS #


#NOT DONE
@app.route('/orders')
def orders():
    return render_template('orders.j2')







































## TO BE DELETED ##


@app.route('/planets')
def planets():
    return render_template('planet.j2')

@app.route('/certifications')
def certifications():
    return render_template('certifications.j2')

@app.route('/people_certified')
def people_certified():
    return render_template('people_certified.j2')














# route for people page
@app.route("/people", methods=["POST", "GET"])
def people():
    # Separate out the request methods, in this case this is for a POST
    # insert a person into the bsg_people entity
    if request.method == "POST":
        # fire off if user presses the Add Person button
        if request.form.get("Add_Person"):
            # grab user form inputs
            fname = request.form["fname"]
            lname = request.form["lname"]
            homeworld = request.form["homeworld"]
            age = request.form["age"]

            # account for null age AND homeworld
            if age == "" and homeworld == "0":
                # mySQL query to insert a new person into bsg_people with our form inputs
                query = "INSERT INTO bsg_people (fname, lname) VALUES (%s, %s)"
                cur = mysql.connection.cursor()
                cur.execute(query, (fname, lname))
                mysql.connection.commit()

            # account for null homeworld
            elif homeworld == "0":
                query = "INSERT INTO bsg_people (fname, lname, age) VALUES (%s, %s,%s)"
                cur = mysql.connection.cursor()
                cur.execute(query, (fname, lname, age))
                mysql.connection.commit()

            # account for null age
            elif age == "":
                query = "INSERT INTO bsg_people (fname, lname, homeworld) VALUES (%s, %s,%s)"
                cur = mysql.connection.cursor()
                cur.execute(query, (fname, lname, homeworld))
                mysql.connection.commit()

            # no null inputs
            else:
                query = "INSERT INTO bsg_people (fname, lname, homeworld, age) VALUES (%s, %s,%s,%s)"
                cur = mysql.connection.cursor()
                cur.execute(query, (fname, lname, homeworld, age))
                mysql.connection.commit()

            # redirect back to people page
            return redirect("/people")

    # Grab bsg_people data so we send it to our template to display
    if request.method == "GET":
        # mySQL query to grab all the people in bsg_people
        query = "SELECT bsg_people.id, fname, lname, bsg_planets.name AS homeworld, age FROM bsg_people LEFT JOIN bsg_planets ON homeworld = bsg_planets.id"
        cur = mysql.connection.cursor()
        cur.execute(query)
        data = cur.fetchall()

        # mySQL query to grab planet id/name data for our dropdown
        query2 = "SELECT id, name FROM bsg_planets"
        cur = mysql.connection.cursor()
        cur.execute(query2)
        homeworld_data = cur.fetchall()

        # render edit_people page passing our query data and homeworld data to the edit_people template
        return render_template("people.j2", data=data, homeworlds=homeworld_data)


# route for delete functionality, deleting a person from bsg_people,
# we want to pass the 'id' value of that person on button click (see HTML) via the route
@app.route("/delete_people/<int:id>")
def delete_people(id):
    # mySQL query to delete the person with our passed id
    query = "DELETE FROM bsg_people WHERE id = '%s';"
    cur = mysql.connection.cursor()
    cur.execute(query, (id,))
    mysql.connection.commit()

    # redirect back to people page
    return redirect("/people")


# route for edit functionality, updating the attributes of a person in bsg_people
# similar to our delete route, we want to the pass the 'id' value of that person on button click (see HTML) via the route
@app.route("/edit_people/<int:id>", methods=["POST", "GET"])
def edit_people(id):
    if request.method == "GET":
        # mySQL query to grab the info of the person with our passed id
        query = "SELECT * FROM bsg_people WHERE id = %s" % (id)
        cur = mysql.connection.cursor()
        cur.execute(query)
        data = cur.fetchall()

        # mySQL query to grab planet id/name data for our dropdown
        query2 = "SELECT id, name FROM bsg_planets"
        cur = mysql.connection.cursor()
        cur.execute(query2)
        homeworld_data = cur.fetchall()

        # render edit_people page passing our query data and homeworld data to the edit_people template
        return render_template("edit_people.j2", data=data, homeworlds=homeworld_data)

    # meat and potatoes of our update functionality
    if request.method == "POST":
        # fire off if user clicks the 'Edit Person' button
        if request.form.get("Edit_Person"):
            # grab user form inputs
            id = request.form["personID"]
            fname = request.form["fname"]
            lname = request.form["lname"]
            homeworld = request.form["homeworld"]
            age = request.form["age"]

            # account for null age AND homeworld
            if (age == "" or age == "None") and homeworld == "0":
                # mySQL query to update the attributes of person with our passed id value
                query = "UPDATE bsg_people SET bsg_people.fname = %s, bsg_people.lname = %s, bsg_people.homeworld = NULL, bsg_people.age = NULL WHERE bsg_people.id = %s"
                cur = mysql.connection.cursor()
                cur.execute(query, (fname, lname, id))
                mysql.connection.commit()

            # account for null homeworld
            elif homeworld == "0":
                query = "UPDATE bsg_people SET bsg_people.fname = %s, bsg_people.lname = %s, bsg_people.homeworld = NULL, bsg_people.age = %s WHERE bsg_people.id = %s"
                cur = mysql.connection.cursor()
                cur.execute(query, (fname, lname, age, id))
                mysql.connection.commit()

            # account for null age
            elif age == "" or age == "None":
                query = "UPDATE bsg_people SET bsg_people.fname = %s, bsg_people.lname = %s, bsg_people.homeworld = %s, bsg_people.age = NULL WHERE bsg_people.id = %s"
                cur = mysql.connection.cursor()
                cur.execute(query, (fname, lname, homeworld, id))
                mysql.connection.commit()

            # no null inputs
            else:
                query = "UPDATE bsg_people SET bsg_people.fname = %s, bsg_people.lname = %s, bsg_people.homeworld = %s, bsg_people.age = %s WHERE bsg_people.id = %s"
                cur = mysql.connection.cursor()
                cur.execute(query, (fname, lname, homeworld, age, id))
                mysql.connection.commit()

            # redirect back to people page after we execute the update query
            return redirect("/people")


# Listener
# change the port number if deploying on the flip servers
if __name__ == "__main__":
    app.run(port=8087, debug=True)
